import React from 'react';

class Clock extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            initialTime: new Date(),
        };
        this.tick = this.tick.bind(this);
    }

    componentDidMount() {
        this.tickId = setInterval(() => this.tick(), 1000);
    }

    componentWillUnmount() {
        //remove interval
        clearInterval(this.tickId);
    }

    tick(){
        this.setState({ initialTime: new Date()});
    }
 
    render() {
        const dateTime = this.state.initialTime.toUTCString();
        const date = dateTime.split(" ").slice(0,4).join(" ");
        const time = dateTime.split(" ").slice(4).join(" ");
        return (
        <>
            <h1>Clock</h1>
            <section className="clock-box wide-box">
                <div>
                    <span>Time:</span>
                    <span>{time}</span>
                </div>
                <div>
                    <span>Date:</span>
                    <span>{date}</span>
                </div>
            </section>
        </>
        );
    }
}

export default Clock;