import React from 'react'

class Tabs extends React.Component {
    constructor (props) {
        super(props);
        this.state = {
            selectedTabID: 0
        };
        this.tabID = 0;
        this.changeTab = this.changeTab.bind(this);
    }

    changeTab () {
        this.setState({selectedTabID: this.tabID});
    }

    render () {
        const tabs = this.props.tabs;
        // debugger
        const allTitles = tabs.map((tab, idx) => {
            this.tabID = `${idx}`
            return <li onClick={this.changeTab} id={idx}>{tab.title}</li>;
        })

        const content = tabs[this.state.selectedTabID].content

        return (
            <>
                <ul className="tabs">{allTitles}</ul>
                <ul className="tab-content">{content}</ul>
            </>
        )
    }
}

export default Tabs;