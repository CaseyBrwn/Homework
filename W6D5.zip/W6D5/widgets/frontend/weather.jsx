import React from 'react';

class Weather extends React.Component {
    constructor(props) {
        super(props);

    }
}



export default Weather;