import React from 'react';
import ReactDOM from 'react-dom';
import App from './frontend/App';

// import Weather from './frontend/weather';

document.addEventListener('DOMContentLoaded', () => {
    const root = document.getElementById("root");

    ReactDOM.render(<App/>, root);
});
